package com.invest.disclosure;

import lombok.Data;

@Data
public class DisclosureList {

	String corp_code;
	String corp_name;
	String report_nm;
	String flr_nm;
	String rcept_dt;
	
}
