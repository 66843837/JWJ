package com.invest.user.dto;

import lombok.Data;

@Data
public class UserAccountInfo {
	
	private String userid;
	private String userName;
	private long balance;
	private String accountid;
}
