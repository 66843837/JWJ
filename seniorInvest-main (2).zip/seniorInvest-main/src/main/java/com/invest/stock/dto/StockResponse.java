package com.invest.stock.dto;

import lombok.Data;

@Data
public class StockResponse {
	
	private StockBody body;
	
	
}
