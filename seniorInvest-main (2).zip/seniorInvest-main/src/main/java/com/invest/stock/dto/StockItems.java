package com.invest.stock.dto;

import java.util.List;

import lombok.Data;

@Data
public class StockItems {
	
	private List<StockDto> item;

}
