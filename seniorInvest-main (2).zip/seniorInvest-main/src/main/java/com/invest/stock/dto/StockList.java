package com.invest.stock.dto;

import lombok.Data;

@Data		
public class StockList {

	private StockResponse response;
	
	
}
